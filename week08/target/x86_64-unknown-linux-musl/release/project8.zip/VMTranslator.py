import subprocess
import sys

subprocess.call(['./week08',  sys.argv[1]])

